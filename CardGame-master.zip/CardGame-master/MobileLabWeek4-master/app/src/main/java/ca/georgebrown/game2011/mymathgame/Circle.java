package ca.georgebrown.game2011.mymathgame;

/**
 * Created by Tech on 2018-02-13.
 */

public class Circle {
    Point m_center;
    float m_radius;
}
