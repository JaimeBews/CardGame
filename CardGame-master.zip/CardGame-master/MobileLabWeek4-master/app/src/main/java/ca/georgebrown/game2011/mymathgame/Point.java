package ca.georgebrown.game2011.mymathgame;

/**
 * Created by Tech on 2018-02-13.
 */

public class Point {
    private int x;
    private int y;

    public Point(int paramX, int paramY) {
        x = paramX;
        y = paramY;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
